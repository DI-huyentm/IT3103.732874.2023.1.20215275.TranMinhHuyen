package Lab01;

// Example 2: FirstDialog.java

import javax.swing.JOptionPane;

public class FirstDialog {
    public static void main ( String[] args) {
        // Display the dialog
        JOptionPane.showMessageDialog(null, "Hello!! How are you?");
        System.exit(0);
    }
}
