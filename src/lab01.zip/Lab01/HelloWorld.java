package Lab01;

// Example 1: HelloWorld.java
// Text-printing program

public class HelloWorld {
    public static void main(String[] args) {
        // Print the phrase
        System.out.println("Hello!");
        System.out.println("I'm Tran Minh Huyen.");

    } // end of method
}